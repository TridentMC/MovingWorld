package com.elytradev.movingworld.common.experiments.newassembly;

/**
 * Used to write a block collection to a world.
 */
public class WorldWriter {
}
