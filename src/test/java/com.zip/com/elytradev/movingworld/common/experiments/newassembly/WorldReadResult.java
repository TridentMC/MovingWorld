package com.elytradev.movingworld.common.experiments.newassembly;

/**
 * Created by darkevilmac on 11/15/2016.
 */
public class WorldReadResult {
}
