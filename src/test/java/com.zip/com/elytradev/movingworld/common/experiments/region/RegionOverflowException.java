package com.elytradev.movingworld.common.experiments.region;

/**
 * Created by darkevilmac on 11/15/2016.
 */
public class RegionOverflowException extends RuntimeException {
}
