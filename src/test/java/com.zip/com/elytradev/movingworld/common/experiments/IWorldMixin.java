package com.elytradev.movingworld.common.experiments;

/**
 * Created by darkevilmac on 2/14/2017.
 */
public interface IWorldMixin {

    void onInstantiate(int dimension);

}
